const db = require('../config/db');

class TestCaseDAO {
    async addTestCase(testcase) {
        const { testcase_name, description, last_run_time, status, type_of_test, assigned_to, priority } = testcase;
        const query = `
            INSERT INTO testcases (testcase_name, description, last_run_time, status, type_of_test, assigned_to, priority)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING *;
        `;
        const values = [testcase_name, description, last_run_time, status, type_of_test, assigned_to, priority];
        const { rows } = await db.query(query, values);
        return rows[0];
    }

    async getTestCaseById(id) {
        const query = 'SELECT * FROM testcases WHERE id = $1';
        const { rows } = await db.query(query, [id]);
        return rows[0];
    }

    async updateTestCase(id, updates) {
        const { testcase_name, description, last_run_time, status, type_of_test, assigned_to, priority } = updates;

        const setClauses = [];
        const values = [];
        let paramCount = 1;

        if (testcase_name !== undefined) setClauses.push(`testcase_name = $` + paramCount++);
        if (description !== undefined) setClauses.push(`description = $` + paramCount++);
        if (last_run_time !== undefined) setClauses.push(`last_run_time = $` + paramCount++);
        if (status !== undefined) setClauses.push(`status = $` + paramCount++);
        if (type_of_test !== undefined) setClauses.push(`type_of_test = $` + paramCount++);
        if (assigned_to !== undefined) setClauses.push(`assigned_to = $` + paramCount++);
        if (priority !== undefined) setClauses.push(`priority = $` + paramCount++);
        
        setClauses.push(`updated_at = CURRENT_TIMESTAMP`);

        const updateValues = [
            testcase_name,
            description,
            last_run_time,
            status,
            type_of_test,
            assigned_to,
            priority
        ].filter(val => val !== undefined);

        values.push(...updateValues, id);

        const query = `
            UPDATE testcases
            SET ${setClauses.join(', ')}
            WHERE id = $` + paramCount + `
            RETURNING *;
        `;
        const { rows } = await db.query(query, values);
        return rows[0];
    }

    async deleteTestCase(id) {
        const query = 'DELETE FROM testcases WHERE id = $1 RETURNING *;';
        const { rows } = await db.query(query, [id]);
        return rows[0];
    }

    async getAllTestCases() {
        const query = 'SELECT * FROM testcases';
        const { rows } = await db.query(query);
        return rows;
    }

    async queryTestCases(filters) {
        let query = 'SELECT * FROM testcases WHERE 1=1';
        const values = [];
        let paramCount = 1;

        for (const key in filters) {
            if (filters[key]) {
                query += ` AND ${key} ILIKE $` + paramCount++;
                values.push(`%${filters[key]}%`);
            }
        }
        const { rows } = await db.query(query, values);
        return rows;
    }
}

module.exports = new TestCaseDAO(); 