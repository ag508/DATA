const fs = require('fs');
const { parse } = require('csv-parser');
const { createObjectCsvWriter } = require('csv-writer');
const testCaseService = require('../service/testCaseService');
const EmptyTestcaseStatus = require('../exceptions/exceptions');

async function importTestCases(filePath) {
    return new Promise((resolve, reject) => {
        const testCases = [];
        fs.createReadStream(filePath)
            .pipe(parse({ headers: true }))
            .on('error', error => reject(error))
            .on('data', (row) => {
                const testcase = {
                    testcase_name: row.testcase_name,
                    description: row.description || null,
                    last_run_time: row.last_run_time ? new Date(row.last_run_time) : null,
                    status: row.status,
                    type_of_test: row.type_of_test || null,
                    assigned_to: row.assigned_to || null,
                    priority: row.priority ? parseInt(row.priority) : null,
                };
                testCases.push(testcase);
            })
            .on('end', async () => {
                try {
                    for (const testcase of testCases) {
                        await testCaseService.addTestCase(testcase);
                    }
                    resolve(`${testCases.length} test cases imported successfully.`);
                } catch (error) {
                    reject(error);
                }
            });
    });
}

async function exportTestCases(filePath) {
    const testCases = await testCaseService.getAllTestCases();
    if (testCases.length === 0) {
        return "No test cases to export.";
    }

    const csvWriter = createObjectCsvWriter({
        path: filePath,
        header: [
            { id: 'id', title: 'ID' },
            { id: 'testcase_name', title: 'Test Case Name' },
            { id: 'description', title: 'Description' },
            { id: 'last_run_time', title: 'Last Run Time' },
            { id: 'status', title: 'Status' },
            { id: 'type_of_test', title: 'Type of Test' },
            { id: 'assigned_to', title: 'Assigned To' },
            { id: 'priority', title: 'Priority' },
            { id: 'created_at', title: 'Created At' },
            { id: 'updated_at', title: 'Updated At' },
        ]
    });

    await csvWriter.writeRecords(testCases);
    return `${testCases.length} test cases exported successfully to ${filePath}.`;
}

module.exports = { importTestCases, exportTestCases }; 