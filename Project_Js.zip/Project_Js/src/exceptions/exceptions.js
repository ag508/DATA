class EmptyTestcaseStatus extends Error {
    constructor(message) {
        super(message);
        this.name = "EmptyTestcaseStatus";
    }
}

module.exports = EmptyTestcaseStatus; 