const testCaseDAO = require('../dao/testCaseDAO');
const EmptyTestcaseStatus = require('../exceptions/exceptions');

class TestCaseService {
    async addTestCase(testcase) {
        if (!testcase.status) {
            throw new EmptyTestcaseStatus("Testcase status cannot be empty.");
        }
        return testCaseDAO.addTestCase(testcase);
    }

    async getTestCaseById(id) {
        return testCaseDAO.getTestCaseById(id);
    }

    async updateTestCase(id, updates) {
        if (updates.status !== undefined && !updates.status) {
            throw new EmptyTestcaseStatus("Testcase status cannot be empty.");
        }
        return testCaseDAO.updateTestCase(id, updates);
    }

    async deleteTestCase(id) {
        return testCaseDAO.deleteTestCase(id);
    }

    async getAllTestCases() {
        return testCaseDAO.getAllTestCases();
    }

    async queryTestCases(filters) {
        return testCaseDAO.queryTestCases(filters);
    }
}

module.exports = new TestCaseService(); 