const readline = require('readline-sync');
const testCaseService = require('./src/service/testCaseService');
const { importTestCases, exportTestCases } = require('./src/handlers/csvHandler');
const EmptyTestcaseStatus = require('./src/exceptions/exceptions');

async function main() {
    console.log("Welcome to the Test Case Tracker CLI!");

    while (true) {
        console.log("\nChoose an operation:");
        console.log("1. Add Test Case");
        console.log("2. Get Test Case by ID");
        console.log("3. Update Test Case");
        console.log("4. Delete Test Case");
        console.log("5. Get All Test Cases");
        console.log("6. Query Test Cases");
        console.log("7. Import Test Cases from CSV");
        console.log("8. Export Test Cases to CSV");
        console.log("9. Exit");

        const choice = readline.question("Enter your choice: ");

        try {
            switch (choice) {
                case '1':
                    await addTestCaseCLI();
                    break;
                case '2':
                    await getTestCaseByIdCLI();
                    break;
                case '3':
                    await updateTestCaseCLI();
                    break;
                case '4':
                    await deleteTestCaseCLI();
                    break;
                case '5':
                    await getAllTestCasesCLI();
                    break;
                case '6':
                    await queryTestCasesCLI();
                    break;
                case '7':
                    await importTestCasesCLI();
                    break;
                case '8':
                    await exportTestCasesCLI();
                    break;
                case '9':
                    console.log("Exiting Test Case Tracker. Goodbye!");
                    process.exit(0);
                default:
                    console.log("Invalid choice. Please try again.");
            }
        } catch (error) {
            if (error instanceof EmptyTestcaseStatus) {
                console.error(`Error: ${error.message}`);
            } else {
                console.error("An unexpected error occurred:", error.message);
            }
        }
    }
}

async function addTestCaseCLI() {
    console.log("\n--- Add New Test Case ---");
    const testcase_name = readline.question("Test Case Name: ");
    const description = readline.question("Description (optional): ");
    const last_run_time_str = readline.question("Last Run Time (YYYY-MM-DD HH:MM:SS, optional): ");
    const last_run_time = last_run_time_str ? new Date(last_run_time_str) : null;
    const status = readline.question("Status (failed, passed, pending, skipped): ");
    const type_of_test = readline.question("Type of Test (optional): ");
    const assigned_to = readline.question("Assigned To (optional): ");
    const priority_str = readline.question("Priority (number, optional): ");
    const priority = priority_str ? parseInt(priority_str) : null;

    const newTestCase = {
        testcase_name,
        description,
        last_run_time,
        status,
        type_of_test,
        assigned_to,
        priority
    };

    try {
        const addedTestCase = await testCaseService.addTestCase(newTestCase);
        console.log("Test Case added successfully:", addedTestCase);
    } catch (error) {
        if (error instanceof EmptyTestcaseStatus) {
            console.error(`Error: ${error.message}`);
        } else {
            console.error("Error adding test case:", error.message);
        }
    }
}

async function getTestCaseByIdCLI() {
    console.log("\n--- Get Test Case by ID ---");
    const id = readline.questionInt("Enter Test Case ID: ");
    const testCase = await testCaseService.getTestCaseById(id);
    if (testCase) {
        console.log("Test Case found:", testCase);
    } else {
        console.log(`Test Case with ID ${id} not found.`);
    }
}

async function updateTestCaseCLI() {
    console.log("\n--- Update Test Case ---");
    const id = readline.questionInt("Enter Test Case ID to update: ");
    const existingTestCase = await testCaseService.getTestCaseById(id);

    if (!existingTestCase) {
        console.log(`Test Case with ID ${id} not found.`);
        return;
    }

    console.log("Enter new values (leave blank to keep current):");
    const updates = {};
    const testcase_name = readline.question(`Test Case Name (${existingTestCase.testcase_name}): `);
    if (testcase_name) updates.testcase_name = testcase_name;

    const description = readline.question(`Description (${existingTestCase.description || ''}): `);
    if (description) updates.description = description;

    const last_run_time_str = readline.question(`Last Run Time (${existingTestCase.last_run_time ? new Date(existingTestCase.last_run_time).toISOString() : ''}, YYYY-MM-DD HH:MM:SS): `);
    if (last_run_time_str) updates.last_run_time = new Date(last_run_time_str);

    const status = readline.question(`Status (${existingTestCase.status}): `);
    if (status) updates.status = status;

    const type_of_test = readline.question(`Type of Test (${existingTestCase.type_of_test || ''}): `);
    if (type_of_test) updates.type_of_test = type_of_test;

    const assigned_to = readline.question(`Assigned To (${existingTestCase.assigned_to || ''}): `);
    if (assigned_to) updates.assigned_to = assigned_to;

    const priority_str = readline.question(`Priority (${existingTestCase.priority || ''}): `);
    if (priority_str) updates.priority = parseInt(priority_str);

    try {
        const updatedTestCase = await testCaseService.updateTestCase(id, updates);
        console.log("Test Case updated successfully:", updatedTestCase);
    } catch (error) {
        if (error instanceof EmptyTestcaseStatus) {
            console.error(`Error: ${error.message}`);
        } else {
            console.error("Error updating test case:", error.message);
        }
    }
}

async function deleteTestCaseCLI() {
    console.log("\n--- Delete Test Case ---");
    const id = readline.questionInt("Enter Test Case ID to delete: ");
    const deletedTestCase = await testCaseService.deleteTestCase(id);
    if (deletedTestCase) {
        console.log("Test Case deleted successfully:", deletedTestCase);
    } else {
        console.log(`Test Case with ID ${id} not found.`);
    }
}

async function getAllTestCasesCLI() {
    console.log("\n--- All Test Cases ---");
    const testCases = await testCaseService.getAllTestCases();
    if (testCases.length > 0) {
        testCases.forEach(tc => console.log(tc));
    } else {
        console.log("No test cases found.");
    }
}

async function queryTestCasesCLI() {
    console.log("\n--- Query Test Cases ---");
    console.log("Enter filter criteria (leave blank for no filter):");
    const filters = {};
    filters.testcase_name = readline.question("Test Case Name (partial match): ");
    filters.status = readline.question("Status: ");
    filters.type_of_test = readline.question("Type of Test: ");
    filters.assigned_to = readline.question("Assigned To: ");

    const queriedTestCases = await testCaseService.queryTestCases(filters);
    if (queriedTestCases.length > 0) {
        queriedTestCases.forEach(tc => console.log(tc));
    } else {
        console.log("No test cases found matching the criteria.");
    }
}

async function importTestCasesCLI() {
    console.log("\n--- Import Test Cases from CSV ---");
    const filePath = readline.question("Enter the path to the CSV file: ");
    try {
        const message = await importTestCases(filePath);
        console.log(message);
    } catch (error) {
        console.error("Error importing test cases:", error.message);
    }
}

async function exportTestCasesCLI() {
    console.log("\n--- Export Test Cases to CSV ---");
    const filePath = readline.question("Enter the desired output CSV file path: ");
    try {
        const message = await exportTestCases(filePath);
        console.log(message);
    } catch (error) {
        console.error("Error exporting test cases:", error.message);
    }
}

main(); 